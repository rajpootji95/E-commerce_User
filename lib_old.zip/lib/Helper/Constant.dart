final String appName = 'Delris User';

final String packageName = 'com.delris.user';
final String androidLink = 'https://play.google.com/store/apps/details?id=';

final String iosPackage = 'com.delris.user';
final String iosLink = 'your ios link here';
final String appStoreId = 'com.delris.user';

final String deepLinkUrlPrefix = 'https://alpha.ecommerce.link';
final String deepLinkName = 'alpha.ecommerce.link';

final int timeOut = 50;
const int perPage = 10;

// final String baseUrl = 'https://buransmart.in/app/v1/api/';
final String baseUrl = 'https://delristech-projects.in/php/ecommerce/app/v1/api/';

final String imageUrl = 'https://delristech-projects.in/php/ecommerce/';

final String jwtKey = "e1e421dceee9ea718ab764ea4fdef95629e7f415";
